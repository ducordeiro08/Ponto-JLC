@echo off
setlocal
cd /d "%~dp0"
start "TOTH API 3333" cmd /k "%~dp0iniciar-api.bat"
start "TOTH WEB 5173 5174" cmd /k "%~dp0iniciar-sites-local.bat"
echo.
echo TOTH iniciado.
echo.
echo Gestao:      http://localhost:5174
echo Funcionario: http://localhost:5173
echo API:         http://localhost:3333/health
echo.
pause
