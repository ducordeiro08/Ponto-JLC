@echo off
setlocal
cd /d "%~dp0"
node servidor-web-estatico.mjs
