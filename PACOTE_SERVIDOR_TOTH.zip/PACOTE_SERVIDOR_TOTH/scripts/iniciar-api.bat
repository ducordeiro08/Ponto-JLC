@echo off
setlocal
cd /d "%~dp0..\api"
set "TOTH_API_HOST=0.0.0.0"
set "TOTH_API_PORT=3333"
set "TOTH_DATABASE_PATH=%CD%\database\toth.sqlite"
set "TOTH_MANAGEMENT_PASSWORD=toth123"
node dist-backend\backend\server.js
