import { createReadStream, existsSync, statSync } from "node:fs";
import { createServer } from "node:http";
import { extname, join, normalize, resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");

const sites = [
  { name: "TOTH Funcionario PWA", port: 5173, dir: join(root, "web", "funcionario-pwa") },
  { name: "TOTH Gestao", port: 5174, dir: join(root, "web", "gestao") },
];

const contentTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".webmanifest": "application/manifest+json; charset=utf-8",
};

function sendFile(response, filePath) {
  response.writeHead(200, {
    "Content-Type": contentTypes[extname(filePath)] || "application/octet-stream",
    "Cache-Control": "no-cache",
  });
  createReadStream(filePath).pipe(response);
}

function createStaticServer(site) {
  return createServer((request, response) => {
    const url = new URL(request.url || "/", "http://localhost");
    const requestedPath = normalize(decodeURIComponent(url.pathname)).replace(/^(\.\.[/\\])+/, "");
    let filePath = resolve(site.dir, `.${requestedPath}`);

    if (!filePath.startsWith(resolve(site.dir))) {
      response.writeHead(403);
      response.end("Forbidden");
      return;
    }

    if (!existsSync(filePath) || statSync(filePath).isDirectory()) {
      filePath = join(site.dir, "index.html");
    }

    sendFile(response, filePath);
  });
}

for (const site of sites) {
  createStaticServer(site).listen(site.port, "0.0.0.0", () => {
    console.log(`${site.name}: http://localhost:${site.port}`);
  });
}
