@echo off
setlocal
cd /d "%~dp0..\api"
npm install --omit=dev
pause
