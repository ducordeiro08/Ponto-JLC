# Pacote Servidor TOTH

Esta pasta foi preparada para ser copiada para outro computador/servidor.

Ela contem:

- API central do TOTH
- Banco SQLite central atual
- TOTH Gestao web
- TOTH Funcionario PWA
- Scripts para iniciar em ambiente local/rede

## Estrutura

```text
PACOTE_SERVIDOR_TOTH/
  api/
    dist-backend/
    database/
      toth.sqlite
    package.json
    package-lock.json
  web/
    gestao/
    funcionario-pwa/
  scripts/
    iniciar-api.bat
    iniciar-sites-local.bat
    iniciar-tudo.bat
    servidor-web-estatico.mjs
```

## Requisitos no outro computador

Instale antes:

- Node.js
- npm, que ja vem junto com o Node.js

Para conferir:

```powershell
node -v
npm -v
```

## Primeiro uso no outro computador

Entre na pasta da API:

```powershell
cd "CAMINHO\PACOTE_SERVIDOR_TOTH\api"
```

Instale as dependencias:

```powershell
npm install --omit=dev
```

Isso precisa ser feito pelo menos uma vez.

## Como iniciar tudo

Depois de instalar as dependencias, execute:

```text
PACOTE_SERVIDOR_TOTH\scripts\iniciar-tudo.bat
```

Esse script abre:

- API na porta 3333
- TOTH Gestao na porta 5174
- TOTH Funcionario PWA na porta 5173

## Links locais no servidor

No proprio computador servidor:

```text
http://localhost:5174
http://localhost:5173
http://localhost:3333/health
```

## Links para outros computadores na mesma rede

Descubra o IP do servidor:

```powershell
ipconfig
```

Se o IP for, por exemplo, `192.168.0.197`, acesse:

```text
http://192.168.0.197:5174
http://192.168.0.197:5173
```

## O que cada porta significa

```text
3333 = API central
5174 = TOTH Gestao
5173 = TOTH Funcionario PWA
```

## Banco de dados

O banco que foi copiado esta em:

```text
api/database/toth.sqlite
```

O script `iniciar-api.bat` ja configura a API para usar esse banco.

## Firewall

Se outros computadores nao conseguirem acessar, libere as portas no Windows do servidor.

Abra PowerShell como administrador:

```powershell
New-NetFirewallRule -DisplayName "TOTH API 3333" -Direction Inbound -Protocol TCP -LocalPort 3333 -Action Allow
New-NetFirewallRule -DisplayName "TOTH Gestao 5174" -Direction Inbound -Protocol TCP -LocalPort 5174 -Action Allow
New-NetFirewallRule -DisplayName "TOTH Funcionario PWA 5173" -Direction Inbound -Protocol TCP -LocalPort 5173 -Action Allow
```

## Observacao importante sobre producao

Este pacote funciona para rede local e testes.

Para producao profissional na internet, o ideal e usar:

- HTTPS
- dominio proprio
- backup automatico do banco
- servidor configurado para reiniciar a API automaticamente
- proxy reverso, como Nginx, IIS ou Cloudflare Tunnel

